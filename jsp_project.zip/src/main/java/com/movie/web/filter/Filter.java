package com.movie.web.filter;

public interface Filter {

}
