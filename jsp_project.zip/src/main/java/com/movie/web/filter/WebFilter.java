package com.movie.web.filter;

public @interface WebFilter {

    String value();

}
