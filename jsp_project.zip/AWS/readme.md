# Putty 사용

**https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html 접속 > 다운로드 후 PrivateKey 파일 저장 > Putty실행 > [Category > Connection > SSH > Auth > Credentials > Public-Key authentication > Private key file for authentication > Browse...] > 저장했던 PrivateKey 지정 > Session > HostName(or IP address)에 > 15.164.30.145 입력 > Port(22) > Open > 사용자 계정: ubuntu 입력**

# error

- **No supported authentication methods available**
  - **PuTTY > Connection > SSH > Auth > Private Key file for authentication > PrivateKey 확인**
